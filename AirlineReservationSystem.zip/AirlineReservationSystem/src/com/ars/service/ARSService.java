package com.ars.service;

import java.sql.SQLException;
import java.util.List;

import com.ars.dao.ARSDao;
import com.ars.dao.IARSDao;
import com.ars.dtobean.FlightBean;
import com.ars.dtobean.UsersBean;
import com.ars.exception.AirlineException;

public class ARSService implements IARSService {
static IARSDao idao=null;
	
	
	@Override
	public UsersBean getDetailsServ(UsersBean airbean) throws SQLException {
		
		idao=new ARSDao();
		
		return idao.getDetailsDao(airbean);
	}


	@Override
	public List<FlightBean> getFlightDetails() throws AirlineException {
		
		idao=new ARSDao();
		return idao.getFlightDetails();
	}


	@Override
	public FlightBean validateFlight(int fno) throws AirlineException {
		
		idao=new ARSDao();
	
		return idao.validateFlight(fno);
	}

	
	
	
	
	
	
	
}
