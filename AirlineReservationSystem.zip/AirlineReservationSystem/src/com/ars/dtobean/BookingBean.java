package com.ars.dtobean;

public class BookingBean {

	private String customerMail;
	private int passengers;
	private String classType;
	private int totalFare;
	private int seatNumber;
	private String creditCardNo;
	private String srcCity;
	private String destCity;
	
	public String getCustomerMail() {
		return customerMail;
	}
	public void setCustomerMail(String customerMail) {
		this.customerMail = customerMail;
	}
	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
	public int getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}
	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getCreditCardNo() {
		return creditCardNo;
	}
	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}
	public String getSrcCity() {
		return srcCity;
	}
	public void setSrcCity(String srcCity) {
		this.srcCity = srcCity;
	}
	public String getDestCity() {
		return destCity;
	}
	public void setDestCity(String destCity) {
		this.destCity = destCity;
	}
	
	public BookingBean(String customerMail, int passengers, String classType, int totalFare, int seatNumber,
			String creditCardNo, String srcCity, String destCity) {
		super();
		this.customerMail = customerMail;
		this.passengers = passengers;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNumber = seatNumber;
		this.creditCardNo = creditCardNo;
		this.srcCity = srcCity;
		this.destCity = destCity;
	}
	
	
	
	
	
	
	
	
}
