package com.ars.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {

	static Connection conn=null;
	
	public static Connection getConnection() {
		
		String url ="jdbc:oracle:thin:@10.219.34.3:1521/orcl";
		String un  ="trg217";
		String pass="training217";
		
		try
		{
			
			conn=DriverManager.getConnection(url, un, pass);
		}
		catch(SQLException e)
		{
			System.out.println("connection problem :: " + e.getMessage());
		}
		
		
		return conn;
		
	}
	
	
	
	
	
	
}
